package emp_exericse;

// VO = DTO

public class EmpVO {
	// #####  멤버변수 선언

	
	
}
